<?php

?>
<style>
    .text-muted{
        text-align: center;
    }
</style>
<footer id="footer" class="footer mt-4 py-3">
        <div class="container">
            <center>
            <span class="text-muted">&copy;&nbsp;<?php echo date("Y");?> a product of Willie Scant company</span>
            </center>
        </div>
</footer>

